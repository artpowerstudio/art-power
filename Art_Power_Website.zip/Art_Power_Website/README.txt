ART POWER WEBSITE

Files:
- index.html: responsive one-page website template

How to preview:
1. Open index.html in a browser.
2. Internet is needed to load the external sample photography.

Before publishing:
- Replace the sample phone number, email, and location with your real business details.
- The WhatsApp number in both links and the contact form must be replaced with your business WhatsApp number in international digits, without + or spaces.
- Replace sample photography with photos of your actual projects.
- Upload index.html to a hosting provider/domain. This is a front-end template; it does not include a server, online payments, or a database.
